# Customer360 Power BI — Build Guide

This guide helps you build the `customer-engagement-dashboard.pbix` in minutes using the provided assets.

## 1) Import Data
- Open Power BI Desktop.
- Get Data → Text/CSV → import the four files in this order:
  1. Calendar.csv
  2. Customers.csv
  3. Opportunities.csv
  4. EngagementLogs.csv

## 2) Data Types
- Ensure date columns are Date type:
  - Calendar[Date], Customers[CreatedAt], Opportunities[CreatedDate], Opportunities[CloseDate], EngagementLogs[EventDate]

## 3) Relationships
- Opportunities[CustomerId] → Customers[CustomerId] (Many-to-One)
- EngagementLogs[CustomerId] → Customers[CustomerId] (Many-to-One)
- Opportunities[CreatedDate] → Calendar[Date] (Many-to-One)
- EngagementLogs[EventDate] → Calendar[Date] (Many-to-One)

## 4) Measures
- Create a table called `Measures`.
- Paste the content of `DAX_Measures.txt` into new measures.

## 5) Theme
- View → Themes → Browse for themes → select `customer360_theme.json`.

## 6) Suggested Pages & Visuals

### Page 1 — Executive Overview
- Cards: Total Leads, Total Customers, Closed Won Amount, Conversion Rate
- Line chart (Calendar[Date] vs Closed Won Amount)
- Funnel: Opps Qual → Prop → Neg → Won
- Slicers: Year, Segment, Owner

### Page 2 — Sales Performance
- Clustered column: Amount by Stage
- Matrix: Customer Name vs Amount & Count of Opps
- KPI: Avg Sales Cycle (days)
- Slicer: Source

### Page 3 — Engagement
- Bar chart: Engagement Events by EventType
- Table: Recent EngagementLogs
- Card: Engagement Score (avg)

### Page 4 — Cohorts & Trends
- Area chart: New Leads by Month
- Line chart: Closed Won Amount (YTD) vs Month
- Cohort-style matrix: Customer Created Month vs Opps Won Count

## 7) Save as PBIX
- File → Save As → `customer-engagement-dashboard.pbix`

Done! You now have a functional dashboard fed by realistic sample data.
